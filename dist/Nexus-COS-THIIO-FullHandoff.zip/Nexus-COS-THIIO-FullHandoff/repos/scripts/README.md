# scripts

Part of the Nexus COS monorepo.

## Purpose

This directory contains scripts related code.

## Structure

To be populated with actual implementations.

## Development

See root README for development instructions.
