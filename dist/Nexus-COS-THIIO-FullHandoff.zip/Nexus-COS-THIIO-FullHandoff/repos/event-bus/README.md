# event-bus

Part of the Nexus COS monorepo.

## Purpose

This directory contains event-bus related code.

## Structure

To be populated with actual implementations.

## Development

See root README for development instructions.
