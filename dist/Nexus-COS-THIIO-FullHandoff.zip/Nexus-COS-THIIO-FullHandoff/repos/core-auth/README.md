# core-auth

Part of the Nexus COS monorepo.

## Purpose

This directory contains core-auth related code.

## Structure

To be populated with actual implementations.

## Development

See root README for development instructions.
