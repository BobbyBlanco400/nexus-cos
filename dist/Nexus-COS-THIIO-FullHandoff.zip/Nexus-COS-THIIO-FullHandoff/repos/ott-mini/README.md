# ott-mini

Part of the Nexus COS monorepo.

## Purpose

This directory contains ott-mini related code.

## Structure

To be populated with actual implementations.

## Development

See root README for development instructions.
