"""Unit tests initialization"""
