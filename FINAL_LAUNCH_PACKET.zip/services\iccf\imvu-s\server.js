const express = require('express')
const app = express()
const port = process.env.PORT || 3000
const handshake = process.env.N3XUS_HANDSHAKE || '55-45-17'

app.use(express.json())

app.use((req, res, next) => {
  if (req.path === '/health') {
    return next()
  }
  const header = req.headers['x-n3xus-handshake'] || req.headers['x-nexus-handshake']
  if (!header || header !== handshake) {
    return res.status(403).json({
      error: 'HANDSHAKE_REQUIRED',
      service: 'iccf-imvu-s',
      expected: handshake
    })
  }
  next()
})

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'iccf-imvu-s',
    port,
    phase: 4,
    type: 'IMVU-S',
    timestamp: new Date().toISOString()
  })
})

app.get('/', (req, res) => {
  res.json({
    service: 'iccf-imvu-s',
    status: 'running',
    port
  })
})

app.listen(port, () => {
  process.stdout.write(`iccf-imvu-s listening on ${port}\n`)
})

