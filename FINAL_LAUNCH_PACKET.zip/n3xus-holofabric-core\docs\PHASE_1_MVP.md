☑ Spatial runtime boots locally
☑ LAW handshake enforced
☑ Scene manifest validation
☑ Casino binding enabled
☑ Public LAW status endpoint
☑ Pre-order entitlement gating
☑ Investor demo mode (read-only)
