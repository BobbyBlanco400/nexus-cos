/**
 * Nexus COS Frontend - Index Entry Point
 * This is an alias to main.tsx for compatibility with the PF structure
 */

export { default } from './main';
