"""Integration tests initialization"""
