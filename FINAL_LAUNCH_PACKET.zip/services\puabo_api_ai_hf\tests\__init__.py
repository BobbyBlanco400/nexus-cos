"""Test configuration and initialization"""
