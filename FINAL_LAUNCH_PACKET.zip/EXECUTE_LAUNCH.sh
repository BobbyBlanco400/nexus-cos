#!/bin/bash
set -e

echo "🚀 INITIATING N3XUS v-COS LAUNCH SEQUENCE..."
echo "🔒 AUTHORITY: PUABO HOLDINGS LLC"
echo "🔧 MODE: EMERGENCE PROTOCOL"

# 1. CLEANUP
echo "🧹 Cleaning previous state..."
docker-compose -f docker-compose.full.yml down --remove-orphans || true

# 2. BUILD
echo "🏗️  Building Sovereign Stack (Handshake 55-45-17)..."
docker-compose -f docker-compose.full.yml build --no-cache

# 3. LAUNCH
echo "🔥 Igniting Core Services..."
docker-compose -f docker-compose.full.yml up -d

# 4. WAIT
echo "⏳ Waiting for service stabilization (30s)..."
sleep 30

# 5. VERIFY
echo "🔍 Verifying Health Protocols..."

echo "Checking v-supercore (3001)..."
if curl -s -f http://localhost:3001/health > /dev/null; then
    echo "✅ v-supercore: ONLINE"
else
    echo "❌ v-supercore: FAILED"
fi

echo "Checking puabo-api-ai-hf (3002)..."
if curl -s -f http://localhost:3002/health > /dev/null; then
    echo "✅ puabo-api-ai-hf: ONLINE"
else
    echo "❌ puabo-api-ai-hf: FAILED"
fi

echo "Checking holofabric-runtime (3700)..."
if curl -s -f http://localhost:3700/health > /dev/null; then
    echo "✅ holofabric-runtime: ONLINE"
else
    echo "❌ holofabric-runtime: FAILED"
fi

echo "🎉 LAUNCH SEQUENCE COMPLETE."
echo "📜 ACCESS CREDENTIALS:"
cat ADMIN_CREDENTIALS.txt
echo "🌐 PUBLIC URLS:"
cat FOUNDERS_URL.txt
