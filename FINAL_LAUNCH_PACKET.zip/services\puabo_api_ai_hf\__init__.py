"""
PUABO API/AI-HF Hybrid Service
HuggingFace-powered AI inference service for N3XUS COS
"""

__version__ = "1.0.0"
__author__ = "N3XUS COS Team"
